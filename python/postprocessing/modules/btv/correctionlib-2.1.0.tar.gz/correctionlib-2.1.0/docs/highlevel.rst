correctionlib.highlevel
-----------------------
High-level interface to correction evaluator module. These objects
are also available directly through the ``correctionlib`` namespace.

.. currentmodule:: correctionlib.highlevel
.. autosummary::
    :toctree: _generated

    Correction
    CorrectionSet
