Schema v2
---------
Second iteration of the schema

:download:`Download json <_generated/schemav2.json>`.

.. jsonschema:: _generated/schemav2.json
    :lift_description:
    :lift_definitions:
    :auto_target:
    :auto_reference:
